﻿using Microsoft.Office.Interop.Excel;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.IO;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using Excel = Microsoft.Office.Interop.Excel;
using ios = System.Runtime.InteropServices;
using Rectangle = System.Drawing.Rectangle;

namespace ExcelImage
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        public void ExportRangeAsPng(int imageWidth)
        {
            Excel.Application xl;

            xl = new Microsoft.Office.Interop.Excel.Application(); // (Excel.Application)ios.Marshal.GetActiveObject("Excel.Application");
            xl.Workbooks.Open(@"C:\Users\jrchoi\Documents\RPES 사용자리스트 - 211015.xlsx");
            //Open Template Excel file  
            //Get the first wirksheet in Excel file  
            if (xl == null)
            {
                MessageBox.Show("No Excel !!");
                return;
            }
            Excel.Workbook wb = xl.ActiveWorkbook;
            Excel.Range r = wb.ActiveSheet.Range["A1:E10"];
            r.CopyPicture(Excel.XlPictureAppearance.xlScreen,
                           Excel.XlCopyPictureFormat.xlBitmap);

            if (Clipboard.GetDataObject() != null)
            {

                IDataObject data = Clipboard.GetDataObject();

                if (data.GetDataPresent(DataFormats.Bitmap))
                {
                    Image image = (Image)data.GetData(DataFormats.Bitmap, true);
                    pictureBox1.Image = image;
                    //Bitmap mg = new Bitmap(image);
                    //double f = (double)imageWidth / image.Width;
                    //f = 1;
                    //Size size = new Size(imageWidth, (int)(f * image.Height));
                    //Bitmap bp = ResizeImage(mg, size);
                    //bp.SetResolution(mg.HorizontalResolution, mg.VerticalResolution);
                    //bp.Save(@"C:\Users\jrchoi\Documents\RPES 사용자리스트 - 211015.png", System.Drawing.Imaging.ImageFormat.Png);

                    image.Save(@"C:\Users\jrchoi\Documents\RPES 사용자리스트 - 211015.png", System.Drawing.Imaging.ImageFormat.Png);
                }
                else
                {
                    MessageBox.Show("No image in Clipboard !!");
                }
                xl.Workbooks.Close();
                xl.Quit();
            }
            else
            {
                MessageBox.Show("Clipboard Empty !!");
            }
        }
        private static Bitmap ResizeImage(Bitmap mg, Size newSize)
        {
            double ratio = 0d;
            double myThumbWidth = 0d;
            double myThumbHeight = 0d;
            int x = 0;
            int y = 0;

            Bitmap bp;


            if ((mg.Width / Convert.ToDouble(newSize.Width)) > (mg.Height /
            Convert.ToDouble(newSize.Height)))
                ratio = Convert.ToDouble(mg.Width) / Convert.ToDouble(newSize.Width);
            else
                ratio = Convert.ToDouble(mg.Height) / Convert.ToDouble(newSize.Height);
            myThumbHeight = Math.Ceiling(mg.Height / ratio);
            myThumbWidth = Math.Ceiling(mg.Width / ratio);

            Size thumbSize = new Size((int)myThumbWidth, (int)myThumbHeight);
            bp = new Bitmap(newSize.Width, newSize.Height);
            x = (newSize.Width - thumbSize.Width) / 2;
            y = (newSize.Height - thumbSize.Height);

            System.Drawing.Graphics g = Graphics.FromImage(bp);
            g.SmoothingMode = SmoothingMode.HighQuality;
            g.InterpolationMode = InterpolationMode.HighQualityBicubic;
            g.PixelOffsetMode = PixelOffsetMode.HighQuality;
            Rectangle rect = new Rectangle(x, y, thumbSize.Width, thumbSize.Height);
            g.DrawImage(mg, rect, 0, 0, mg.Width, mg.Height, GraphicsUnit.Pixel);

            return bp;
        }
        //private static Bitmap ResetResolution(Metafile mf, float resolution)
        //{
        //    int width = (int)(mf.Width * resolution / mf.HorizontalResolution);
        //    int height = (int)(mf.Height * resolution / mf.VerticalResolution);
        //    Bitmap bmp = newBitmap(width, height);
        //    bmp.SetResolution(resolution, resolution);
        //    Graphics g = Graphics.FromImage(bmp);
        //    g.DrawImage(mf, 0, 0);
        //    g.Dispose();
        //    return bmp;
        //}
        private void button1_Click(object sender, EventArgs e)
        {
            ExportRangeAsPng(1000);
        }
    }
}
